<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       $curDate = \Carbon\Carbon::now()->format('Y-m-d H:i:s');

        DB::table('users')->insert([
            'name' => 'Test',
            'email' => 'prav.malathi@gmail.com',
            'password' => Hash::make('admin123'),
            'role_id' => 3,
            'is_active' => true,
            'created_at' => $curDate
        ]);

        DB::table('users')->insert([
            'name' => 'Super Admin',
            'email' => 'sadmin@gmail.com',
            'password' => Hash::make('sadmin123'),
            'role_id' => '1',
            'is_active' => true,
            'created_at' => $curDate
        ]);

        DB::table('users')->insert([
            'name' => 'Admin',
            'email' => 'admin@gmail.com',
            'password' => Hash::make('admin123'),
            'role_id' => '2',
            'is_active' => true,
            'created_at' => $curDate
        ]);
    }
}
