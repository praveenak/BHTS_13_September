<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      $curDate = \Carbon\Carbon::now()->format('Y-m-d H:i:s');

      DB::table('roles')->insert([
          'name' => 'SAdmin',
          'created_at' => $curDate
      ]);

      DB::table('roles')->insert([
          'name' => 'Admin',
          'created_at' => $curDate
      ]);

      DB::table('roles')->insert([
          'name' => 'User',
          'created_at' => $curDate
      ]);
    }
}
