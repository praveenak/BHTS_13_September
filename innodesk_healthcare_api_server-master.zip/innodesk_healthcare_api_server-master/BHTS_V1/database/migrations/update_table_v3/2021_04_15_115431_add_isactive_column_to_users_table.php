<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use App\User;

class AddIsactiveColumnToUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      User::truncate(); // empty the table, cannot create a foreign key inside a table with rows

      Schema::table('users', function (Blueprint $table) { //Schema::table() is used for updating an existing table
        $table->boolean('is_active')->default(false);
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
          $table->dropColumn('is_active'); // drop the column
        });
    }
}
