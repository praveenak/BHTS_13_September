<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use App\User;

class AddRoleIdColumnAndForeignConstraintToUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        User::truncate(); // empty the table, cannot create a foreign key inside a table with rows

        Schema::table('users', function (Blueprint $table) { //Schema::table() is used for updating an existing table
          $table->unsignedBigInteger('role_id'); // unsigned for foreign key.
          $table->foreign('role_id') // foreign key column name.
          ->references('id') // parent table primary key.
          ->on('roles') // parent table name.
          ->onDelete('cascade'); // this will delete all the children rows when the parent row is deleted.
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
          $table->dropForeign(['role_id']); // drop the foreign key.
          $table->dropColumn('role_id'); // drop the column
        });
    }
}
