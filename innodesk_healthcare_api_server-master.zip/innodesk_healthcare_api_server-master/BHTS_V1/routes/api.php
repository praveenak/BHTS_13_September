<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//routes for client mobile apps
Route::prefix('user')->group(function () {
  //Route::post('register', 'Custom\UserController@register');
  Route::get('login', 'Custom\UserController@login');

  Route::group(['middleware' => 'token'], function(){
    Route::get('country', 'Custom\UserController@listCountry');
  });
});

//routes for admin panel apps
Route::prefix('admin')->group(function () {
  //Route::post('login', 'Custom\AdminController@login');
  Route::get('login','Custom\UserController@login');

  Route::group(['middleware' => 'token'], function() { //'auth:api'
    Route::get('customers', 'Custom\UserController@listCountry');
  });
});
