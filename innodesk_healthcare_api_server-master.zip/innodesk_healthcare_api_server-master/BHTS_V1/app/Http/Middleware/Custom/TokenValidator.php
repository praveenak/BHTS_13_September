<?php

namespace App\Http\Middleware\Custom;

use Illuminate\Support\Facades\Auth;
use App\User;
use App\Admin;
use App\SuperAdmin;
use Closure;

class TokenValidator
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
      if(!empty(trim($request->input('token')))) {
        $is_exists = User::where('id' , Auth::guard('api')->id())->exists();
        if($is_exists) {
            return $next($request);
        }
      }
      return response()->json('Invalid Token', 401);
    }
}
