<?php

namespace App\Http\Controllers\Custom;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;
use App\Http\Controllers\Custom\ResponseController as ResponseController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\Role;
use Validator;
use Illuminate\Support\Carbon;

class UserController extends ResponseController
{
 //login
 public function login(Request $request)
 {
     $validator = Validator::make($request->all(),
       [
         'username' => 'required|string|email',
         'password' => 'required|alpha_num|min:6'
       ]
     );

     if($validator->fails()){
         return $this->sendError($validator->errors());
     }

     $username = $request->input('username');
     $role_id = $request->input('role');
     $user = User::where([['email','=',$username],['role_id','=',$role_id]])->first();

     if (!$user) {
       $error = "Login Failed, Please check Username/Email/Role Id.";
       return $this->sendError($error, 401);
     }

     $password = $request->input('password');
     if (!Hash::check($password, $user->password))
     {
       $error = "Login Failed, Please check password.";
       return $this->sendError($error, 401);
     }

     if (auth()->attempt(['email'=>$username,'password'=>$password])) {
       $puser = auth()->user();
       if ($puser != null) {
         $objToken = $puser->createToken('BHTS Application');
         $token = $objToken->token;
         $token->expires_at = Carbon::now()->addWeeks(4);
         $token->save();

         $role = Role::where('id', '=', $user->role_id)->first();

         $success['success']      =  true;
         $success['message']      =  "Success! Logged in successfully";
         $success['Content-Type'] =  "application/json";
         $data['name']            =  $puser->name;
         $data['role']            =  $role->name;
         $data['token_type']      =  "Bearer";
         $data['token']           =  $objToken->accessToken;
         $data['expires_at']      =  Carbon::parse(
                                     $token->expires_at)->toDateTimeString();

         $success['data']         =    $data;

         return $this->sendResponse($success);
       } else {
         $error = "Unauthenticateds. User does not exist.";
         return $this->sendError($error, 401);
       }
     }
     else
     {
       $error = "Unauthorized. Login Failed.";
       return $this->sendError($error, 401);
     }
 }

 //logout
 public function logout(Request $request)
 {
     $isUser = $request->user()->token()->revoke();
     if($isUser){
         $success['message'] = "Successfully logged out.";
         return $this->sendResponse($success);
     }
     else{
         $error = "Something went wrong.";
         return $this->sendResponse($error);
     }
  }
}
